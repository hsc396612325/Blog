/***
*findfi64.c - C find file functions
*
*       Copyright (c) 1994-1997, Microsoft Corporation. All rights reserved.
*
*Purpose:
*       Defines _findfirsti64() and _findnexti64().
*
*******************************************************************************/

#define _USE_INT64  1

#include "findfile.c"
