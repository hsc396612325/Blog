/***
*stati64.c - get file status
*
*       Copyright (c) 1994-1997, Microsoft Corporation. All rights reserved.
*
*Purpose:
*       Defines _stati64() - get file status
*
*******************************************************************************/

#define _USE_INT64  1

#include "stat.c"
